package org.example;

public @interface BeforeEach {

}
