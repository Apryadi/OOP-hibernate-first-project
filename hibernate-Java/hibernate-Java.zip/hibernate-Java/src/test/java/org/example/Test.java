package org.example;

public @interface Test {

}
